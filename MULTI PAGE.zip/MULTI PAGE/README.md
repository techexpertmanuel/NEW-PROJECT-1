# HTML Website Structure Project

## Project Overview
This is a simple multi-page HTML website built with semantic structure and SEO meta tags. The website demonstrates proper HTML structure without any CSS styling.

## Features
- Semantic HTML structure using appropriate tags
- Four interconnected pages with consistent navigation
- SEO meta tags on every page
- Accessible forms with proper labels and attributes
- Table elements for structured data
- Proper use of HTML5 semantic elements

## Pages
1. **Homepage (index.html)** - Introduction and featured content
2. **Projects (projects.html)** - Project showcase with table
3. **Articles (articles.html)** - Articles with semantic structure
4. **Contact (contact.html)** - Contact form with various input types

## SEO Implementation
- Meta description and keywords on every page
- Author and robots meta tags
- Open Graph meta tags for social media
- Canonical URLs
- Semantic headings hierarchy
- Alt text for images (to be added when images are included)

## Accessibility Features
- ARIA labels for navigation
- Proper form labels and descriptions
- Semantic landmarks (header, main, footer, nav, etc.)
- Logical heading hierarchy
- Accessible table with caption and scope attributes

## Project Structure
The website follows a consistent structure across all pages:
1. Header with main navigation
2. Main content area with semantic sections
3. Footer with secondary navigation
4. Proper use of articles, sections, and asides

## Next Steps for Styling
This HTML structure is designed to be easily styled with CSS. Key areas for styling:
- Navigation menu styling
- Form input styling
- Table styling
- Responsive design for mobile devices
- Color scheme and typography